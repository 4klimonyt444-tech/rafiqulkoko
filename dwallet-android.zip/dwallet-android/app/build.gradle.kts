plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dwallet.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dwallet.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // ====== EDIT THESE 4 LINES ======
        buildConfigField("String", "BASE_URL", "\"https://dwallet.cc/"")
        buildConfigField("String", "PATH_WALLET", "\"/wallet\"")
        buildConfigField("String", "PATH_P2P", "\"/p2p\"")
        buildConfigField("String", "PATH_PROFILE", "\"/profile\"")
        // ================================
    }

    buildFeatures { buildConfig = true; viewBinding = true }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug") // sideload-ready; use your own keystore for Play Store
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
