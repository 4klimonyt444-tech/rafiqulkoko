package com.dwallet.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.dwallet.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val base = BuildConfig.BASE_URL.trimEnd('/')
    private val baseHost: String = Uri.parse(BuildConfig.BASE_URL).host ?: ""

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermRequest: PermissionRequest? = null

    // Pages shown WITHOUT the bottom bar (login / register / 2FA / password reset)
    private val authWords = listOf("login", "register", "signup", "mfa", "otp", "password", "forgot", "verify-email", "reset")

    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val res = if (r.resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data) else null
        fileCallback?.onReceiveValue(res); fileCallback = null
    }

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        pendingPermRequest?.let { if (ok) it.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else it.deny() }
        pendingPermRequest = null
    }

    private val tabListener = com.google.android.material.navigation.NavigationBarView.OnItemSelectedListener { item ->
        val p = when (item.itemId) {
            R.id.tab_p2p -> BuildConfig.PATH_P2P
            R.id.tab_profile -> BuildConfig.PATH_PROFILE
            else -> BuildConfig.PATH_WALLET
        }
        val cur = Uri.parse(b.webview.url ?: "").path ?: ""
        if (!cur.startsWith(p)) b.webview.loadUrl(base + p)
        true
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val wv = b.webview
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            userAgentString = "$userAgentString DwalletApp/1.0"
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(wv, true) }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (u.host == baseHost) {
                    if ((u.path ?: "/").trim('/').isEmpty()) { v.loadUrl(base + BuildConfig.PATH_WALLET); return true }
                    return false
                }
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, u)) }
                return true
            }

            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) { b.progress.visibility = View.VISIBLE }

            override fun onPageFinished(v: WebView, url: String) {
                b.progress.visibility = View.GONE
                b.swipe.isRefreshing = false
                CookieManager.getInstance().flush()
                // Hide the website's own top menu: the app uses native bottom tabs instead
                v.evaluateJavascript(
                    "(function(){var s=document.createElement('style');" +
                    "s.textContent='header.nav{display:none!important}';" +
                    "document.head.appendChild(s);})();", null)
                updateTabs(url)
            }

            override fun onReceivedError(v: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) {
                    v.loadDataWithBaseURL(null,
                        "<body style='background:#0B0E11;color:#fff;font-family:sans-serif;text-align:center;padding-top:30vh'>" +
                        "<h3>No connection</h3><p>Check your internet and pull down to retry.</p></body>",
                        "text/html", "utf-8", req.url.toString())
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = cb
                return try { fileChooser.launch(p.createIntent()); true } catch (e: Exception) { fileCallback = null; false }
            }

            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    if (req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                        } else { pendingPermRequest = req; camPerm.launch(Manifest.permission.CAMERA) }
                    } else req.deny()
                }
            }
        }

        wv.setDownloadListener { url, _, _, _, _ -> runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }

        b.swipe.setColorSchemeColors(0xFFF0B90B.toInt())
        b.swipe.setOnRefreshListener { wv.reload() }
        b.bottomNav.setOnItemSelectedListener(tabListener)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (wv.canGoBack()) wv.goBack() else finish() }
        })

        if (savedInstanceState == null) wv.loadUrl(base + BuildConfig.PATH_WALLET) else wv.restoreState(savedInstanceState)
    }

    private fun updateTabs(url: String) {
        val u = Uri.parse(url)
        if (u.host != baseHost) return
        val path = (u.path ?: "/").lowercase()
        val isAuth = path.trim('/').isEmpty() || authWords.any { path.contains(it) }
        b.bottomNav.visibility = if (isAuth) View.GONE else View.VISIBLE
        if (isAuth) return
        val id = when {
            path.startsWith(BuildConfig.PATH_P2P.lowercase()) || path.contains("p2p") || path.contains("otc") -> R.id.tab_p2p
            path.startsWith(BuildConfig.PATH_PROFILE.lowercase()) ||
                listOf("security", "rank", "rewards", "pin", "api-key", "support").any { path.contains(it) } -> R.id.tab_profile
            else -> R.id.tab_wallet
        }
        if (b.bottomNav.selectedItemId != id) {
            b.bottomNav.setOnItemSelectedListener(null)
            b.bottomNav.selectedItemId = id
            b.bottomNav.setOnItemSelectedListener(tabListener)
        }
    }

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); b.webview.saveState(out) }
    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }
}
